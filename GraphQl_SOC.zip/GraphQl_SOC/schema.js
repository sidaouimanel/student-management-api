const { GraphQLSchema, GraphQLObjectType, GraphQLString, GraphQLList, GraphQLInt, GraphQLFloat } = require('graphql');
const students = require('./data/Student_data.json');

// Définir le type Student
const StudentType = new GraphQLObjectType({
    name: 'Student',
    fields: () => ({
        studentId: { type: GraphQLInt },
        studyHoursPerDay: { type: GraphQLFloat },
        extracurricularHoursPerDay: { type: GraphQLFloat },
        sleepHoursPerDay: { type: GraphQLFloat },
        socialHoursPerDay: { type: GraphQLFloat },
        physicalActivityHoursPerDay: { type: GraphQLFloat },
        gpa: { type: GraphQLFloat },
        stressLevel: { type: GraphQLString }
    })
});

// Root Query
const RootQuery = new GraphQLObjectType({
    name: 'RootQueryType',
    fields: {
        students: {
            type: new GraphQLList(StudentType),
            resolve(parent, args) {
                return students;
            }
        },
        student: {
            type: StudentType,
            args: { studentId: { type: GraphQLInt } },
            resolve(parent, args) {
                return students.find(student => student.studentId === args.studentId);
            }
        }
    }
});

// Exporter le schéma
module.exports = new GraphQLSchema({
    query: RootQuery
});
