import { ApolloServer } from '@apollo/server';
import { startStandaloneServer } from '@apollo/server/standalone';
import { resolvers } from './service/resolvers.js';

// Schéma GraphQL : Définition des types et des requêtes
const typeDefs = `
  type Student {
    studentId: Int
    studyHoursPerDay: Float
    extracurricularHoursPerDay: Float
    sleepHoursPerDay: Float
    socialHoursPerDay: Float
    physicalActivityHoursPerDay: Float
    gpa: Float
    stressLevel: String
  }

  type Query {
    getAllStudents: [Student]
    getStudentById(studentId: Int): Student
    getStudentsByGpa(minGpa: Float): [Student]
    averageStudyHours: Float
    countStudentsWithHighStress: Int
  }

  input StudentInput {
    studentId: Int
    studyHoursPerDay: Float
    extracurricularHoursPerDay: Float
    sleepHoursPerDay: Float
    socialHoursPerDay: Float
    physicalActivityHoursPerDay: Float
    gpa: Float
    stressLevel: String
  }

  type Mutation {
    addStudent(student: StudentInput): Student
    deleteStudent(studentId: Int): String
  }
`;

// Créer une instance du serveur Apollo
const server = new ApolloServer({ typeDefs, resolvers });

// Démarrer le serveur avec Apollo Server
const { url } = await startStandaloneServer(server, {
  listen: { port: 4000 },
});

console.log(`🚀 Server ready at ${url}`);
/*
//Obtenir tous les étudiants :
query {
  getAllStudents {
    studentId
    studyHoursPerDay
    gpa
    stressLevel
  }
}
//Ajouter un étudiant :
mutation {
  addStudent(student: {
    studentId: 3,
    studyHoursPerDay: 6,
    extracurricularHoursPerDay: 1.5,
    sleepHoursPerDay: 8,
    socialHoursPerDay: 2,
    physicalActivityHoursPerDay: 1,
    gpa: 3.7,
    stressLevel: "Medium"
  }) {
    studentId
    gpa
    stressLevel
  }
}
//Supprimer un étudiant par ID :
mutation {
  deleteStudent(studentId: 1)
}*/