import students from '../data/Student_data.json' assert { type: 'json' };

let studentData = [...students]; // Copier les données JSON pour modification

export const resolvers = {
  Query: {
    getAllStudents: () => studentData,
    getStudentById: (_, { studentId }) =>
      studentData.find(student => student.studentId === studentId),
    getStudentsByGpa: (_, { minGpa }) =>
      studentData.filter(student => student.gpa >= minGpa),
    averageStudyHours: () => {
      const totalHours = studentData.reduce(
        (sum, student) => sum + student.studyHoursPerDay,
        0
      );
      return totalHours / studentData.length;
    },
    countStudentsWithHighStress: () =>
      studentData.filter(student => student.stressLevel === 'High').length,
  },
  Mutation: {
    addStudent: (_, { student }) => {
      studentData.push(student);
      return student;
    },
    deleteStudent: (_, { studentId }) => {
      const index = studentData.findIndex(
        student => student.studentId === studentId
      );
      if (index > -1) {
        studentData.splice(index, 1);
        return `Student with ID ${studentId} deleted successfully.`;
      }
      return `Student with ID ${studentId} not found.`;
    },
  },
};
