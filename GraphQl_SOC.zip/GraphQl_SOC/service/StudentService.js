import fs from 'fs';
import path from 'path';

// Chemin vers le fichier JSON contenant les données des étudiants
const filePath = path.resolve('./data/Student_data.json');

class StudentService {
  constructor() {
    this.loadData();
  }

  // Charger les données du fichier JSON
  loadData() {
    try {
      const data = fs.readFileSync(filePath, 'utf8');
      this.students = JSON.parse(data);
    } catch (err) {
      console.error("Error loading student data:", err.message);
      this.students = [];
    }
  }

  // Sauvegarder les données dans le fichier JSON
  saveData() {
    try {
      fs.writeFileSync(filePath, JSON.stringify(this.students, null, 2), 'utf8');
    } catch (err) {
      console.error("Error saving student data:", err.message);
    }
  }

  // Récupérer tous les étudiants
  getAllStudents() {
    return this.students;
  }

  // Récupérer un étudiant par son ID
  getStudentById(studentId) {
    return this.students.find(student => student.studentId === studentId);
  }

  // Récupérer les étudiants avec un GPA supérieur ou égal à la valeur donnée
  getStudentsByGpa(minGpa) {
    return this.students.filter(student => student.gpa >= minGpa);
  }

  // Calculer la moyenne des heures d'étude par jour
  getAverageStudyHours() {
    const totalHours = this.students.reduce((sum, student) => sum + student.studyHoursPerDay, 0);
    return this.students.length > 0 ? totalHours / this.students.length : 0;
  }

  // Compter les étudiants ayant un niveau de stress élevé
  countStudentsWithHighStress() {
    return this.students.filter(student => student.stressLevel === 'High').length;
  }

  // Ajouter un nouvel étudiant
  addStudent(newStudent) {
    if (this.getStudentById(newStudent.studentId)) {
      throw new Error(`Student with ID ${newStudent.studentId} already exists.`);
    }
    this.students.push(newStudent);
    this.saveData();
    return newStudent;
  }

  // Supprimer un étudiant par son ID
  deleteStudent(studentId) {
    const index = this.students.findIndex(student => student.studentId === studentId);
    if (index === -1) {
      throw new Error(`Student with ID ${studentId} not found.`);
    }
    this.students.splice(index, 1);
    this.saveData();
    return `Student with ID ${studentId} deleted successfully.`;
  }
}

export default new StudentService();
