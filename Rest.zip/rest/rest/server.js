const express = require('express');
const bodyParser = require('body-parser');
const app = express();
const students = require('./data.json');

app.use(bodyParser.json());

let studentData = [...students]; // Copie locale des données JSON

// **CREATE**: Ajouter un étudiant
app.post('/students', (req, res) => {
  const {
    Study_Hours_Per_Day,
    Extracurricular_Hours_Per_Day,
    Sleep_Hours_Per_Day,
    Social_Hours_Per_Day,
    Physical_Activity_Hours_Per_Day,
    GPA,
    Stress_Level
  } = req.body;

  if (!Study_Hours_Per_Day || !GPA || !Stress_Level) {
    return res.status(400).json({ message: 'Certains champs requis sont manquants.' });
  }

  const newStudent = {
    Student_ID: studentData.length + 1,
    Study_Hours_Per_Day,
    Extracurricular_Hours_Per_Day,
    Sleep_Hours_Per_Day,
    Social_Hours_Per_Day,
    Physical_Activity_Hours_Per_Day,
    GPA,
    Stress_Level
  };
  studentData.push(newStudent);
  res.status(201).json(newStudent);
});

// **READ**: Récupérer tous les étudiants
app.get('/students', (req, res) => {
  res.json(studentData);
});

// **READ**: Récupérer un étudiant par ID
app.get('/students/:id', (req, res) => {
  const student = studentData.find(s => s.Student_ID === parseInt(req.params.id));
  if (!student) {
    return res.status(404).json({ message: 'Étudiant non trouvé.' });
  }
  res.json(student);
});

// **UPDATE**: Modifier un étudiant
app.put('/students/:id', (req, res) => {
  const student = studentData.find(s => s.Student_ID === parseInt(req.params.id));
  if (!student) {
    return res.status(404).json({ message: 'Étudiant non trouvé.' });
  }

  const {
    Study_Hours_Per_Day,
    Extracurricular_Hours_Per_Day,
    Sleep_Hours_Per_Day,
    Social_Hours_Per_Day,
    Physical_Activity_Hours_Per_Day,
    GPA,
    Stress_Level
  } = req.body;

  student.Study_Hours_Per_Day = Study_Hours_Per_Day || student.Study_Hours_Per_Day;
  student.Extracurricular_Hours_Per_Day = Extracurricular_Hours_Per_Day || student.Extracurricular_Hours_Per_Day;
  student.Sleep_Hours_Per_Day = Sleep_Hours_Per_Day || student.Sleep_Hours_Per_Day;
  student.Social_Hours_Per_Day = Social_Hours_Per_Day || student.Social_Hours_Per_Day;
  student.Physical_Activity_Hours_Per_Day = Physical_Activity_Hours_Per_Day || student.Physical_Activity_Hours_Per_Day;
  student.GPA = GPA || student.GPA;
  student.Stress_Level = Stress_Level || student.Stress_Level;

  res.json(student);
});

// **DELETE**: Supprimer un étudiant
app.delete('/students/:id', (req, res) => {
  const studentIndex = studentData.findIndex(s => s.Student_ID === parseInt(req.params.id));
  if (studentIndex === -1) {
    return res.status(404).json({ message: 'Étudiant non trouvé.' });
  }

  const deletedStudent = studentData.splice(studentIndex, 1);
  res.json({ message: 'Étudiant supprimé.', student: deletedStudent });
});

// Lancer le serveur sur le port 3001
const PORT = 3001;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
